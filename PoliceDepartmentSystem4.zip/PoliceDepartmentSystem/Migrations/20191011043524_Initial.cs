﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PoliceDepartmentSystem.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Convict",
                columns: table => new
                {
                    ConvictID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ConvictFirstName = table.Column<string>(nullable: false),
                    ConvictLastName = table.Column<string>(nullable: false),
                    ConvictContactNumber = table.Column<string>(nullable: true),
                    ConvictDateOfBirth = table.Column<DateTime>(nullable: true),
                    ConvictAddress = table.Column<string>(nullable: true),
                    Gender = table.Column<string>(nullable: true),
                    Ethnicity = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Convict", x => x.ConvictID);
                });

            migrationBuilder.CreateTable(
                name: "Department",
                columns: table => new
                {
                    DepartmentID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DepartmentName = table.Column<string>(nullable: false),
                    County = table.Column<string>(nullable: false),
                    City = table.Column<string>(nullable: false),
                    State = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Department", x => x.DepartmentID);
                });

            migrationBuilder.CreateTable(
                name: "Victim",
                columns: table => new
                {
                    VictimID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    VictimFirstName = table.Column<string>(nullable: false),
                    VictimLastName = table.Column<string>(nullable: false),
                    VictimContactNumber = table.Column<string>(nullable: true),
                    VictimDateOfBirth = table.Column<DateTime>(nullable: true),
                    VictimAddress = table.Column<string>(nullable: true),
                    Gender = table.Column<string>(nullable: false),
                    Ethnicity = table.Column<string>(nullable: false),
                    IncidentType = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Victim", x => x.VictimID);
                });

            migrationBuilder.CreateTable(
                name: "Officer",
                columns: table => new
                {
                    OfficerID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    OfficerFirstName = table.Column<string>(nullable: false),
                    OfficerLastName = table.Column<string>(nullable: false),
                    OfficerContactNumber = table.Column<string>(nullable: false),
                    DateOfBirth = table.Column<DateTime>(nullable: false),
                    Address = table.Column<string>(nullable: false),
                    IsRetired = table.Column<bool>(nullable: true),
                    JoiningDate = table.Column<DateTime>(nullable: false),
                    DepartmentID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Officer", x => x.OfficerID);
                    table.ForeignKey(
                        name: "FK_Officer_Department_DepartmentID",
                        column: x => x.DepartmentID,
                        principalTable: "Department",
                        principalColumn: "DepartmentID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Case",
                columns: table => new
                {
                    CaseID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CrimeType = table.Column<string>(nullable: false),
                    CrimeDate = table.Column<DateTime>(nullable: false),
                    IsCaseClosed = table.Column<bool>(nullable: true),
                    CrimeClosedDate = table.Column<DateTime>(nullable: true),
                    OfficerID = table.Column<int>(nullable: false),
                    ConvictID = table.Column<int>(nullable: false),
                    VictimID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Case", x => x.CaseID);
                    table.ForeignKey(
                        name: "FK_Case_Convict_ConvictID",
                        column: x => x.ConvictID,
                        principalTable: "Convict",
                        principalColumn: "ConvictID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Case_Officer_OfficerID",
                        column: x => x.OfficerID,
                        principalTable: "Officer",
                        principalColumn: "OfficerID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Case_Victim_VictimID",
                        column: x => x.VictimID,
                        principalTable: "Victim",
                        principalColumn: "VictimID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Case_ConvictID",
                table: "Case",
                column: "ConvictID");

            migrationBuilder.CreateIndex(
                name: "IX_Case_OfficerID",
                table: "Case",
                column: "OfficerID");

            migrationBuilder.CreateIndex(
                name: "IX_Case_VictimID",
                table: "Case",
                column: "VictimID");

            migrationBuilder.CreateIndex(
                name: "IX_Officer_DepartmentID",
                table: "Officer",
                column: "DepartmentID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Case");

            migrationBuilder.DropTable(
                name: "Convict");

            migrationBuilder.DropTable(
                name: "Officer");

            migrationBuilder.DropTable(
                name: "Victim");

            migrationBuilder.DropTable(
                name: "Department");
        }
    }
}
