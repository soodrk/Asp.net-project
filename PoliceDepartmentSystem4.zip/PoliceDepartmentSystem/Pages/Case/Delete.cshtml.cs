﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoliceDepartmentSystem.Models;

namespace PoliceDepartmentSystem.Pages.Case
{
    public class DeleteModel : PageModel
    {
        private readonly PoliceDepartmentSystem.Models.AppDbContext _context;

        public DeleteModel(PoliceDepartmentSystem.Models.AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public PoliceDepartmentSystem.Models.Case Case { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Case = await _context.Case
                .Include(@b => @b.Convict)
                .Include(@b => @b.Officer)
                .Include(@b => @b.Victim).FirstOrDefaultAsync(m => m.CaseID == id);

            if (Case == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Case = await _context.Case.FindAsync(id);

            if (Case != null)
            {
                _context.Case.Remove(Case);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
