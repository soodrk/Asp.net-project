﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoliceDepartmentSystem.Models;

namespace PoliceDepartmentSystem.Pages.Officer
{
    public class IndexModel : PageModel
    {
        private readonly PoliceDepartmentSystem.Models.AppDbContext _context;

        public IndexModel(PoliceDepartmentSystem.Models.AppDbContext context)
        {
            _context = context;
        }

        public IList<PoliceDepartmentSystem.Models.Officer> Officer { get;set; }

        public async Task OnGetAsync()
        {
            Officer = await _context.Officer
                .Include(o => o.Department).ToListAsync();
        }
    }
}
