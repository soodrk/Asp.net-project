﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoliceDepartmentSystem.Models;

namespace PoliceDepartmentSystem.Pages.Victim
{
    public class DeleteModel : PageModel
    {
        private readonly PoliceDepartmentSystem.Models.AppDbContext _context;

        public DeleteModel(PoliceDepartmentSystem.Models.AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public PoliceDepartmentSystem.Models.Victim Victim { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Victim = await _context.Victim.FirstOrDefaultAsync(m => m.VictimID == id);

            if (Victim == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Victim = await _context.Victim.FindAsync(id);

            if (Victim != null)
            {
                _context.Victim.Remove(Victim);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
