﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PoliceDepartmentSystem.Models
{
    public class Case
    {
        [Key]
        public int CaseID { get; set; }
        [Required]
        [Display(Name = "Crime Type")]
        public string CrimeType { get; set; }
        [Required]
        [Display(Name = "Crime Date")]
        public DateTime CrimeDate { get; set; }
        [Display(Name = "Case Closed")]
        public bool? IsCaseClosed { get; set; }

        [Display(Name = "Case Close Date")]
        public DateTime? CrimeClosedDate { get; set; }

        //Relationships

        [Display(Name = "Officer ID")]
        public int OfficerID { get; set; }
        public Officer Officer { get; set; }
        [Display(Name = "Convict ID")]
        public int ConvictID { get; set; }
        public Convict Convict { get; set; }
        [Display(Name = "Victim ID")]
        public int VictimID { get; set; }
        public Victim Victim { get; set; }


        
    }

    


}
