﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PoliceDepartmentSystem.Models;

namespace PoliceDepartmentSystem.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext (DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<PoliceDepartmentSystem.Models.Department> Department { get; set; }

        public DbSet<PoliceDepartmentSystem.Models.Case> Case { get; set; }

        public DbSet<PoliceDepartmentSystem.Models.Convict> Convict { get; set; }

        public DbSet<PoliceDepartmentSystem.Models.Officer> Officer { get; set; }

        public DbSet<PoliceDepartmentSystem.Models.Victim> Victim { get; set; }
    }
}
