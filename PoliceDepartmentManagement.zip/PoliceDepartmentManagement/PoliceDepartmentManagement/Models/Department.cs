﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PoliceDepartmentManagement.Models
{
    public class Department
    {
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }
        public string DepartmentLocation { get; set; }
        public int EmployeeCount { get; set; }

        /*public int CaseID { get; set; }*/
        public ICollection<Case> Cases { get; set; }

        /*public int OfficerID { get; set; }*/

        public ICollection<Officer> Officers { get; set; }

    }
}
