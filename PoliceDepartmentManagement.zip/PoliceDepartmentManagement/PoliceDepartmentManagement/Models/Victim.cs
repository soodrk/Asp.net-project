﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PoliceDepartmentManagement.Models
{
    public class Victim
    {

        public int VictimID { get; set; }
        public string VictimName { get; set; }
        public int VictimAge { get; set; }
        public string VictimAddress { get; set; }
        public string Gender { get; set; }

        //Relationships
        public int CaseID { get; set; }
        public ICollection<Case> Cases { get; set; }
        /*public int OfficerID { get; set; }
        public Officer Officer { get; set; }
        public int ConvictID { get; set; }
        public Convict Convict { get; set; }*/

    }
}
