﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PoliceDepartmentManagement.Models
{
    public class Case
    {
        public string CaseID { get; set; }

        [Required]
        public DateTime CaseStartDate { get; set; }
        public DateTime? CaseClosedDate { get; set; }
        [Required]
        public DateTime IncidentDate { get; set; }
        [Required]
        public DateTime IncidentPlace { get; set; }
        [Required]
        public string CaseDescription { get; set; }
        public bool CaseOpenStatus { get; set; }

        /// <summary>
        ///Relationships between Models
        /// </summary>

        /*public int ConvictID;*/
        public ICollection<Convict> Convicts{ get; set; }

        /*public int VictimID;*/
        public ICollection<Victim> Victims { get; set; }

        public int OfficerID;
        public Officer Officer { get; set; }

    }
}
