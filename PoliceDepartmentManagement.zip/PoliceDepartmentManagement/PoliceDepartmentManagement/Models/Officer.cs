﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PoliceDepartmentManagement.Models
{
    public class Officer
    {
        public int OfficerID { get; set; }
        [Required]
        public string OfficerFirstName { get; set; }
        public string OfficerMiddleName { get; set; }
        [Required]
        public string OfficerLastName { get; set; }
        [Required]
        public int OfficerContactNumber { get; set; }
        [Required]
        public DateTime DateOfBirth { get; set; }
        public string Address { get; set; }
        public bool? IsRetired { get; set; }
        public DateTime JoiningDate { get; set; }
        public DateTime RetirementDate { get; set; }//Need to check in Gattuso's last lecture.

        //Relationships
        /*public int DepartmentID { get; set; }*/
        public ICollection<Department> Departments { get; set; }
        /*public int caseID { get; set; }*/
        public ICollection<Case> Cases { get; set; }
    }
}
