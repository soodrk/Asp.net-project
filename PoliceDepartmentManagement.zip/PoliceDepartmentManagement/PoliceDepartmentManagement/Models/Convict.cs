﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PoliceDepartmentManagement.Models
{
    public class Convict
    {
        [Key]
        public int ConvictID { get; set; }
        [Required]
        public string ConvictFirstName { get; set; }
        public string ConvictMiddleName { get; set; }
        [Required]
        public string ConvictLasttName { get; set; }
        [Required]
        public int ConvictContactNumber { get; set; }
        public int ConvictAge { get; set; }
        public string ConvictAddress { get; set; }
        [Required]
        public string Gender { get; set; }
        [Required]
        public string Ethnicity { get; set; }


     /*   public DateTime IncidentDate { get; set; }
        public string IncidentPlace { get; set; }
        */

        //Relationships
        /*public int CaseID { get; set; }*/
        public ICollection<Case> Cases { get; set; }
/*        public int OfficerID { get; set; }
        public Officer Officer { get; set; }

        public int VictimID { get; set; }
        public Victim Victim { get; set; }*/
    }
}
