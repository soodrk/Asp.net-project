﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoliceDepartmentSystem.Models;

namespace PoliceDepartmentSystem.Pages.Officer
{
    public class DeleteModel : PageModel
    {
        private readonly PoliceDepartmentSystem.Models.AppDbContext _context;

        public DeleteModel(PoliceDepartmentSystem.Models.AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public PoliceDepartmentSystem.Models.Officer Officer { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Officer = await _context.Officer
                .Include(o => o.Department).FirstOrDefaultAsync(m => m.OfficerID == id);

            if (Officer == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Officer = await _context.Officer.FindAsync(id);

            if (Officer != null)
            {
                _context.Officer.Remove(Officer);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
