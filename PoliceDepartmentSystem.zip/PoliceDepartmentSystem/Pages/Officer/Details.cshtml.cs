﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoliceDepartmentSystem.Models;

namespace PoliceDepartmentSystem.Pages.Officer
{
    public class DetailsModel : PageModel
    {
        private readonly PoliceDepartmentSystem.Models.AppDbContext _context;

        public DetailsModel(PoliceDepartmentSystem.Models.AppDbContext context)
        {
            _context = context;
        }

        public PoliceDepartmentSystem.Models.Officer Officer { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Officer = await _context.Officer
                .Include(o => o.Department).FirstOrDefaultAsync(m => m.OfficerID == id);

            if (Officer == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
