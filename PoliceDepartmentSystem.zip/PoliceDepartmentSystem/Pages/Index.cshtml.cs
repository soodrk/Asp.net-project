﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoliceDepartmentSystem.Models;

namespace PoliceDepartmentSystem.Pages
{
    public class IndexModel : PageModel
    {
        private readonly PoliceDepartmentSystem.Models.AppDbContext _context;

        public IndexModel(PoliceDepartmentSystem.Models.AppDbContext context)
        {
            _context = context;
        }

        public IList<PoliceDepartmentSystem.Models.Victim> Victim { get;set; }

        public async Task OnGetAsync()
        {
            Victim = await _context.Victim.ToListAsync();
        }
    }
}
