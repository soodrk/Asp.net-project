﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using PoliceDepartmentSystem.Models;

namespace PoliceDepartmentSystem.Pages.Case
{
    public class CreateModel : PageModel
    {
        private readonly PoliceDepartmentSystem.Models.AppDbContext _context;

        public CreateModel(PoliceDepartmentSystem.Models.AppDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
        ViewData["ConvictID"] = new SelectList(_context.Set<PoliceDepartmentSystem.Models.Convict>(), "ConvictID", "ConvictFirstName");
        ViewData["OfficerID"] = new SelectList(_context.Set<PoliceDepartmentSystem.Models.Officer>(), "OfficerID", "OfficerID");
        ViewData["VictimID"] = new SelectList(_context.Set<PoliceDepartmentSystem.Models.Victim>(), "VictimID", "Ethnicity");
            return Page();
        }

        [BindProperty]
        public PoliceDepartmentSystem.Models.Case Case { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Case.Add(Case);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}