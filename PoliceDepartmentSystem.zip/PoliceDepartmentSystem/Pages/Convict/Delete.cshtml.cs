﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoliceDepartmentSystem.Models;

namespace PoliceDepartmentSystem.Pages.Convict
{
    public class DeleteModel : PageModel
    {
        private readonly PoliceDepartmentSystem.Models.AppDbContext _context;

        public DeleteModel(PoliceDepartmentSystem.Models.AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public PoliceDepartmentSystem.Models.Convict Convict { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Convict = await _context.Convict.FirstOrDefaultAsync(m => m.ConvictID == id);

            if (Convict == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Convict = await _context.Convict.FindAsync(id);

            if (Convict != null)
            {
                _context.Convict.Remove(Convict);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
