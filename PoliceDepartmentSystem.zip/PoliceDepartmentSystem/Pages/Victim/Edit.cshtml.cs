﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PoliceDepartmentSystem.Models;

namespace PoliceDepartmentSystem.Pages.Victim
{
    public class EditModel : PageModel
    {
        private readonly PoliceDepartmentSystem.Models.AppDbContext _context;

        public EditModel(PoliceDepartmentSystem.Models.AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public PoliceDepartmentSystem.Models.Victim Victim { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Victim = await _context.Victim.FirstOrDefaultAsync(m => m.VictimID == id);

            if (Victim == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(Victim).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VictimExists(Victim.VictimID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool VictimExists(int id)
        {
            return _context.Victim.Any(e => e.VictimID == id);
        }
    }
}
