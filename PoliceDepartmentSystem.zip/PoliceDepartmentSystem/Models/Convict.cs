﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PoliceDepartmentSystem.Models
{
    public class Convict
    {
        [Key]

        public int ConvictID { get; set; }
        [Required]
        [Display(Name = "First Name")]
        [RegularExpression(@"^[A - Z]$")]
        public string ConvictFirstName { get; set; }

        
        [Required]
        [Display(Name = "Last Name")]
        [RegularExpression(@"^[A - Z]$")]
        public string ConvictLastName { get; set; }

        [Display(Name = "Contact Number")]
        [RegularExpression(@"^[0-9]{1,10}$")]
        public string ConvictContactNumber { get; set; }
        
        
        [DataType(DataType.Date)]
        [Display(Name = "Date Of Birth")]

        public DateTime? ConvictDateOfBirth { get; set; }
        [Display(Name = "Address")]
        public string ConvictAddress { get; set; }
        public string Gender { get; set; }
        public string Ethnicity { get; set; }

    }
}
