﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PoliceDepartmentSystem.Models
{
    public class Victim
    {
        [Key]
        public int VictimID { get; set; }

        [Required]
        [RegularExpression(@"^[a - zA - Z]$")]
        [Display(Name = "First Name")]
        public string VictimFirstName { get; set; }

        [Required]
        [RegularExpression(@"^[a - zA - Z]$")]
        [Display(Name = "Last Name")]
        public string VictimLastName { get; set; }
        [Display(Name = "Contact Number")]

        [RegularExpression(@"^[0-9]{1,10}$")]
        public string VictimContactNumber { get; set; } // Use validations
        
        [DataType(DataType.Date)]
        [Display(Name = "Date Of Birth")]
        public DateTime? VictimDateOfBirth { get; set; }
        [Display(Name = "Address")]
        public string VictimAddress { get; set; }
        [Required]
        public string Gender { get; set; }
        [Required]
        public string Ethnicity { get; set; }
        [Required]
        public string IncidentType { get; set; }


    }
}
