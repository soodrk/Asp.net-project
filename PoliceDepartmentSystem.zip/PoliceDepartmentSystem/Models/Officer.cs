﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PoliceDepartmentSystem.Models
{
    public class Officer
    {
        [Key]
        public int OfficerID { get; set; }

        [Required]
      //  [RegularExpression(@"^[a - zA - Z]$")]
        [Display(Name = "First Name")]
        public string OfficerFirstName { get; set; }

        [Required]
        //[RegularExpression(@"^[a - zA - Z]$")]
        [Display(Name = "Last Name")]
        public string OfficerLastName { get; set; }

        [Required]
        //[RegularExpression(@"^[0 - 9]{1, 10}$")]
        [Display(Name = "Contact Number")]
        public string OfficerContactNumber { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Date Of Birth")]
        //[CustomValidation(typeof(Officer), "DateOfBirthValidation")]
        public DateTime DateOfBirth { get; set; }

        [Required]
        [Display(Name = "Address")]
        public string Address { get; set; }
        [Display(Name = "Retired")]
        public bool? IsRetired { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Joining Date")]
        public DateTime JoiningDate { get; set; } // number of years in service    

        //Relationships
        [Display(Name = "Department Name")]
        public int DepartmentID { get; set; }
        public Department Department { get; set; }
        public ICollection<Case> Cases { get; set; }

        public static ValidationResult DateOfBirthValidation(DateTime dob, ValidationContext v)
        {
            if (dob.GetType() == typeof(DateTime) && dob < DateTime.Now)
                return ValidationResult.Success;
            return new ValidationResult("Date of Birth date should be more than Current Date");
        }
      }
}
