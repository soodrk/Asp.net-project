﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PoliceDepartmentSystem.Models
{
    public class Victim
    {
        [Key]
        public int VictimID { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 4, ErrorMessage = "First Name should have atleast 4 letters")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Name cannot have alphabets")]
        [Display(Name = "First Name")]
        public string VictimFirstName { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 4, ErrorMessage = "Name should have atleast 4 letters")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Name cannot have alphabets")]
        
        public string VictimLastName { get; set; }
        [Display(Name = "Contact Number")]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        public string VictimContactNumber { get; set; } // Use validations
        
        [DataType(DataType.Date)]
        [CustomValidation(typeof(Officer), "DateOfBirthValidation")]
        [Display(Name = "Date Of Birth")]
        public DateTime? VictimDateOfBirth { get; set; }
        [Display(Name = "Address")]
        public string VictimAddress { get; set; }
        [Required]
        public string Gender { get; set; }
        [Required]
        public string Ethnicity { get; set; }
        [Required]
        public string IncidentType { get; set; }

        public static ValidationResult DateOfBirthValidation(DateTime dob, ValidationContext v)
        {
            if (dob.GetType() == typeof(DateTime) && dob < DateTime.Now)
                return ValidationResult.Success;
            return new ValidationResult("Check Date of Birth!");
        }
    }
}
