﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PoliceDepartmentSystem.Models
{
    public class Department
    {
        [Key]
        public int DepartmentID { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Department Name should have atleast 4 letters")]
        [Display(Name = "Department Name")]
        public string DepartmentName { get; set; }

        [Required]
        public string County { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public string State { get; set; }
        //Relationships
        public ICollection<Officer> Officers { get; set; }
    }
}
