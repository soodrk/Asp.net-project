﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoliceDepartmentSystem.Models;

namespace PoliceDepartmentSystem.Pages.Case
{
    public class DetailsModel : PageModel
    {
        private readonly PoliceDepartmentSystem.Models.AppDbContext _context;

        public DetailsModel(PoliceDepartmentSystem.Models.AppDbContext context)
        {
            _context = context;
        }

        public PoliceDepartmentSystem.Models.Case Case { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Case = await _context.Case
                .Include(@a => @a.Convict)
                .Include(@a => @a.Officer)
                .Include(@a => @a.Victim).FirstOrDefaultAsync(m => m.CaseID == id);

            if (Case == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
