﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoliceDepartmentSystem.Models;

namespace PoliceDepartmentSystem.Pages
{
    public class IndexModel : PageModel
    {
        private readonly PoliceDepartmentSystem.Models.AppDbContext _context;
        public int NumberOfDepartment;
        public int NumberOfOfficers;
        public int NumberOfConvicts;
        public int NumberOfVictims;
        public int NumberOfCases;
        public IndexModel(PoliceDepartmentSystem.Models.AppDbContext context)
        {
            _context = context;
        }

        public IList<PoliceDepartmentSystem.Models.Victim> Victim { get; set; }

        public void OnGet()
        {
            NumberOfDepartment = _context.Department
                                                   .Count();

            NumberOfOfficers = _context.Officer
                                              .Count();
            NumberOfConvicts = _context.Convict
                                              .Count();
            NumberOfVictims = _context.Victim
                                              .Count();
            NumberOfCases = _context.Case
                                          .Count();

        }
    }
}
